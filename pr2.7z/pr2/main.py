import math
a=-0.9
b=1
h=0.3
while a<b:
    y=(math.e)**a+math.sqrt(1+math.e**(2*a))-2
    print(f'y={y}')
    a+=h
while a<b:
    y=1-a**2/2*(math.cos(a))-x/2*(math.sin(a))
    a=a+h
    print(f'y={y}')