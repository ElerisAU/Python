# a=1
# S=['idol','fire']
# SO=['not idle','not fire']
# while a<5:
#     b=S.append('C')
#     SO=S.append(SO)
#     a+=1
#     break
# print(S)
b=0
a=input()
l = list(a)
for i in range(a.__len__()):
    if a[i]==',':
        l[i]='ю'
        b+=1
for i in range(l.__len__()):
    print(l[i])
print(b)