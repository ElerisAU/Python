str = '123456789'
print('вывод с помощью положительных индексов')
c3 = str[2]
print(c3)
c5 = str[4]
print(c5)
c567 = str[4:7]
print(c567)
print('вывод с помощью отрицательных индексов')
c23 = str[-7]
print(c23)
c25 = str[-5]
print(c25)
a = str[-5:-2]
print(a)


st='кот'
print(st)
'st[2]+st[1]+st[0]=ток'
print('ток')


list=['ndfjsl','bsrbefjg','fnjfsw']
print(list[0],list[-1])


