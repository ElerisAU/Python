
n=int(input())
fact = 1
for i in range (1, n+1):
    fact*=i
print(fact)

a=int(input(min))
b=int(input(max))
c=int(input(step))
for i in range(a,b,c):
    print(i)